function clearAction()
	triggerServerEvent("UCDactions.clearAction", resourceRoot)
	return true
end

