local disabledHUD = {"ammo", "health", "armour", "breath", "clock", "money", "weapon", "wanted"}

function getDisabledHUD()
	return disabledHUD
end