function onClientPlayerGetJob(jobName)
	
end
addEvent("onClientPlayerGetJob", true)
addEventHandler("onClientPlayerGetJob", root, onClientPlayerGetJob)
