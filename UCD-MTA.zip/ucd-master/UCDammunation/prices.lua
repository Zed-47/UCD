prices = 
{
	-- [weaponID] = {gunPrice, ammoPrice}
	
	-- Guns
	[22] = {10000, 3}, -- Colt
	[23] = {20000, 15}, -- Silenced
	[24] = {16000, 3}, -- Deagle
	[25] = {24000, 20}, --- Shotgun
	[26] = {32000, 20}, -- Sawed-off
	[27] = {38000, 20}, -- Spas
	[30] = {45000, 12}, -- AK47
	[31] = {61000, 12}, -- M4
	[28] = {21000, 8}, -- Uzi
	[32] = {21000, 8}, -- Tec9
	[29] = {16000, 6}, -- MP5
	[33] = {29000, 35}, -- Country rifle
	[34] = {65000, 50}, -- Sniper
	[38] = {7500000, 12}, -- Minigun
	
	-- Explosives
	[16] = {nil, 1500}, -- Grenade
	[18] = {nil, 1500}, -- Molotov
	[39] = {nil, 1500}, -- Satchel
	[17] = {nil, 1500}, -- Teargas
}
